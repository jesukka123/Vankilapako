# Simple-JailBreak-System
_**(Dont touch Version2 it wont work and idk how to delete it lmao) This is also no longer being supported by me the developer, for any inqury or help visit my stream @ twitch.tv/NaClholic and join the discord**_
#
A simple jailbreaking script that allows someone to get broken out of jail by hacking the gates and getting far enough away from the prison, This also adds a prison interior with security cameras. 

_**Requires**_
1. An item in your database (Default is "keycard" hopefully you can just use the SQL)
2. **Everything the Base Mods require**

#
**ORIGINAL BASE MODS I USED (Don't sue me lads):** 

1.https://github.com/qalle-fivem/esx-qalle-jail 

2.https://github.com/mwhitt1985/Hacking-Doorlock

3.https://github.com/GHMatti/FiveM-Scripts/tree/master/mhacking

4.https://forum.fivem.net/t/release-security-cams/138694
#
Special thanks to KillaMike and huge special shoutout to LowQualityPlays, without their help and support this project would not have been possible <3  

_**Update**_ *ESX RESOURCE* This is an updated and more finalized, working version of the JailBreak System! This adds locked cells to the Interior of the prison (accessed through the "New Inmate Door" through the main gates on the left side, Watchable security cameras (accessed through the computer in evidence locker under police station), gates that can be hacked with a "keycard", Sends a notification to police when hacking is taking place, and also automatically Un-Jails someone when they get far enough away from the prison! 

_**Feature Summary:**_ 

1. Hackable Gates
2. Prison Interior
3. Watchable Security Cameras (From PD)
4. Jail Escapes

_**Installation:**_

1. Just replace esx-qalle-jail with your current jail resource (**MAKE SURE YOU DONT HAVE A CONFLICTING PRISON INTERIOR AS THIS ADDS ONE FOR YOU, IT'S NICE JUST TRUST ME, screen-shots later...**)  
2. Add all mods to your server.cfg (**ex. start esx_doorlock_mhacking**)  

_**Future Plans**_
1. Make it so you can't die in the prison
2. Dissable emotes while jailed (or specific emotes)
3. Add more cameras without it breaking 
4. Finish adding all the cell doors to the config for the lazy bones

_**NOTE**_ Some of the cell doors are not locked as I have not had the time to add them but can be easily added in the config folder for esx_doorlock_mhacking, This is not a replacement for regular mhacking but is suggested you dont use regular esx_doorlock, All rights go to the Geniuses at FiveM and Rockstar and the original creators of the mods used as bases, thank you <3


