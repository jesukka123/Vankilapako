Locales ['sv'] = {
	['unlocked'] = '~g~Olåst~s~',
	['locked'] = '~r~Låst~s~',
	['press_button'] = '[E] %s',
}
