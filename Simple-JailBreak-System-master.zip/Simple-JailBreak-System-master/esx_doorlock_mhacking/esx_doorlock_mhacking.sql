INSERT INTO `items` (name, label, `limit`) VALUES
	('keycard', 'Keycard', -1)
;