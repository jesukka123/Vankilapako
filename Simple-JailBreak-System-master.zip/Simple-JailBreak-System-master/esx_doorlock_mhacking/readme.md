All credit goes to @zr0iq and @Hawaii_Beach

Requires 'mhacking' and 'esx'.

This resource allows one to hack all locked doors within esx_doorlock. 

The hacking will not begin until the player has the item 'keycard' on them. I have included the sql for the item.

