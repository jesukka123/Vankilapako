# esx_securitycam

### Requirements
* ES_EXTENDED
  * [es_extended] (https://github.com/ESX-Org/es_extended)

* ESX_POLICEJOB
  * [esx_policejob] (https://github.com/ESX-Org/esx_policejob)
  
* MHACKING
  * [mhacking] (https://github.com/GHMatti/FiveM-Scripts)
  
* PNOTIFY
  * [pNotify] (https://github.com/Nick78111/pNotify)

## Download & Installation

### Download
- Download https://github.com/LifeGoal/esx_securitycam
- Put it in the `[esx]` directory
- Add `start esx_securitycam` to your server.cfg

## Configuration
-  * Look at the WIKI and you will get all the information you need!

# Original Code
Thanks to xander1998 for the original code (Non ESX). 
  * [securitycams] (https://github.com/xander1998/securitycams)

# Legal
### License
[Please read the license before using this.]

<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License</a>.
